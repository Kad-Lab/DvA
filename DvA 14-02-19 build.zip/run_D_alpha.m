clear;
D_v_a_GUI;