%addpath('C:\Users\nkad\Dropbox\Papers\XPD paper\Trajectory data\');
hold('off'); figure(D_v_a_GUI);
%clearvars -except FileName PathName windows;
PathName = evalin('base', 'PathName');
window = evalin('base', 'windows(1)');
%Load file used by DVA
cd(PathName); 
FileName = evalin('base', 'FileName');
  f = fopen(FileName);
  C = textscan(f, '%f32 %f32', 'HeaderLines', 1);% use the following if there is a header to be removed, "'HeaderLines', 1);"
  test = transpose(C{1,1});
  fclose(f);
 
 % Plot Diffusion data
 
 load('diff_stor.mat'); load('alph_stor.mat'); % load data from most recent analysis
 diff = cell2mat(diff_stor); %convert cell to normal data variable
 alph = cell2mat(alph_stor); %convert cell to normal data variable
 thr = (log10(diff)./(abs(alph))); %Threshold determinant
 av_thr = nanmean(reshape([thr(:); nan(mod(-numel(thr),round(size(alph,2)/100)),1)],round(size(alph,2)/100),[])); %downsample by averaging over n/100 points
 
 plot (av_thr)
 xlim([0 100])
 ylim([(min(av_thr)/10) 0])
 %axis auto;
 global X1 Y1 rescaled;
 if rescaled == 1;
     axis ([0 X1 0 Y1]);
 
 end
 [x y] = ginput(1); %get x & y position from mouse cursor
 
  
 %Determine from threshold what is above and below the line
 hold('on'); pause = 1;diff_count =1;pause_end=0; pause_start=0; diff_end = 0;
 pauseflag = 0;
  for pos = 2:size(av_thr,2);
     if av_thr(1,pos) > y
         thresh(1,pos) = 1;
         if pauseflag > 0 && thresh(1,pos-1) < 1; %check it was in a pause
             pause_end(pause) = pos; diff_start(diff_count) = pos; 
             pauseflag = 0; pause = pause + 1; diff_count = diff_count + 1;
         %diff_start is the time of the diffusion period
         elseif thresh(1,pos-1) < 1;
             diff_start(diff_count) = pos;
             diff_count = diff_count + 1;
         end
     else
        thresh(1,pos) = 0;
        if thresh(1,pos-1) > 0;
             pause_start(pause) = pos; diff_end(diff_count) = pos; 
             pauseflag = 1;
         end
     end
 end

 
 
 plot(thresh*(min(av_thr)/50), 'r-');
 % For those events that start but the acquisition ends before the event
 % ends, this removes the last start time.
 
 if size(pause_start,2) > size(pause_end,2);  
     pause_start(pause) = [];
 end
 life = pause_end - pause_start; life(life<0) = [];
 
 %Lifetime of diffusion events recorded in life_diff
 
 diff_end(diff_end==0) = [];
 if size(diff_start,2) > size(diff_end,2);  
     diff_start((end)) = [];
 end
 life_diff = diff_end - diff_start; life_diff(life_diff<0) = []; 
 
 %Check if you are happy with the fit
 y
 Decide; 

% Save data files

% save('life','life'); %saves the lifetime variable as a matlab file if
% needed
%save lifetime variable as an appended text file
filepart = 'life_pause.txt';
fileID = fopen(filepart,'at');
fprintf(fileID,'%1.4f\n', life);
fclose(fileID);

%save lifetime of diffusion events variable as an appended text file
filepart = 'life_diff.txt';
fileID = fopen(filepart,'at');
fprintf(fileID,'%1.4f\n', life_diff);
fclose(fileID);

filepart = ['diff_', FileName]; %This saves the diff constant values as a text file for each one analysed
fileID = fopen(filepart,'w');
fprintf(fileID,'Threshold = %4.6f\r\n', y); %a two line header with the threshold
fprintf(fileID,'Window = %4.2f\r\n', window); % and the sliding window size
fprintf(fileID,'%1.4f\r\n', diff);
fclose(fileID);

 load('alph_stor.mat'); % load data from most recent analysis
 alph = cell2mat(alph_stor); %convert cell to normal data variable
 
filepart = ['alph_', FileName]; %This saves the alph values as a text file for each one analysed
fileID = fopen(filepart,'w');
fprintf(fileID,'%1.4f\r\n', alph);
fclose(fileID);

