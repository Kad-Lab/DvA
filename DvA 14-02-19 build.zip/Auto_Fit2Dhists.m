%To use this, simply load any file from the directory containing the
%alph_stor and diff_stor you want to analyse. 
%This program takes just the pathname from the user-interfaced file loading

clearvars;

%17-3-18 stand-alone automatic number of windows and files detected.
%declare variables

filepos = 0; winpos = 0; %filepos is the incrementing filenumber and window is an incremented window number


%Load files
[FileName,PathName] = uigetfile('*.mat');
cd(PathName);


 load('diff_stor.mat'); % load data 
 load('alph_stor.mat'); % load data 
 window = size ((diff_stor),1); % determine number of windows
 filenum = size ((diff_stor),2);% determine number of files
 
while filepos < filenum; % set up loop to increment file number
    
    filepos = filepos +1;
    
    for winpos = 1:window; % sub-loop that increments window number for each file
    dva(:,1) = log(transpose(cell2mat(diff_stor(winpos,filepos)))); %convert and transpose diff
    dva(:,2) = transpose(cell2mat(alph_stor(winpos,filepos))); %convert and transpose alph

% for q = 1:2 %for a series of components uncomment this
q=2; %remove this when running the q loop in line above
%plot(logx(:,1),logx(:,2), 'o')
plot(dva(:,1),dva(:,2), 'o'); % Plots dva
hold on;
options = statset('Display','final');
obj = gmdistribution.fit(dva,q,'Options',options); %Change q to a number and get rid of the for next loop to fit a single
%obj = fitgmdist(logx,2);

 %h = ezcontour(@(x,y)pdf(obj,[x y]),[-10 2 -2 2]); 
 %val = ezcontour(h, [-10 2 -2 2]);
hold off;
% These commands extract the anti-log of logD and the BIC
% inlogx=exp(obj.mu(:,1))
% obj.mu(:,2)
% bic(2,q)= obj.BIC;
% bic (1,q) = q;

% end %Relates to the q loop above
    

 %Record files
 fit_log(2*filepos:2*filepos+1,1) = filepos; % write filenumber to fit_log
 fit_log(1,(3*winpos-1):(3*winpos+1)) = winpos; % write window to fit_log
 fit_log(2*filepos:2*filepos+1,(3*winpos-1):(3*winpos)) = obj.mu; % write LogD and alpha fits to fit_log
 fit_log(2*filepos:2*filepos+1,(3*winpos+1)) = transpose(obj.ComponentProportion); % write component proportion to fit_log
 clearvars dva; %necessary to redimension the dva array
    end
    
end
 
 save('fit_params','fit_log'); % obvo!
 
 
 hold on;
 h = ezcontour(@(x,y)pdf(obj,[x y]),[-10 2 -2 2]); 
 val = ezcontour(h, [-10 2 -2 2]);
 
 
 
 % f = transpose(bic);
% clf;
% plot(f(1,:), f(2,:));


% for k = 1:4
% obj{k} = gmdistribution.fit(logx,k);
% BIC(k)= obj{k}.BIC;
% end
% [minBIC,numComponents] = min(BIC);
% % numComponents


% The following is to create 2D hists using covariance to alter their
% shape. This is really good for understanding the meaning of the vector
% components.

% mu = [-5.25979 0.783676];
% SIGMA = [0.835 -0.0515; -0.0515 0.1452];
% r = mvnrnd(mu,SIGMA,1000);
% mu2 = [-8.94171 0.325911];
% SIGMA2 = [2.898 0.1287; 0.1287 0.0294];
% r2 = mvnrnd(mu2,SIGMA2,1000);
% plot(r(:,1),r(:,2),'+'); hold on
% plot(r2(:,1),r2(:,2),'r+')
% axis([-15 0 -1 2]);
% hold off;