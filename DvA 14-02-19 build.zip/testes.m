%Output from this program is in um^2/s
%Input is in the form of pixels 

%This program uses the contents of 'test' to create an MV and DvsA plot. It
%is necessary to 'paste to workspace' the displacement values of a
%molecule from Excel. Then rename the variable 'test', which can be done in the import
%window. Before processing you will need to transpose using: 
%test = transpose(test);
%copy this command into the command window and then run, this changes the
%orientation of the plot to rows. 
% The time is incremental from one in steps of one, therefore all diffusion constants will
% need correction to the time increment of the frame rate.
% After processing copy out alph and diff into an excel workbook.
% The fit quality has to be adjusted by eye, changing the values of block
% and of windowwidth:
figure(D_v_a_GUI);

% block = 50; %Mean var sliding window width
%windowidth = evalin('base','wind'); %D vs a sliding window width
k = 0;
reject = zeros(1,3);
%2-12-12
%Added multiple file loader
 FileName = evalin('base', 'FileName');
 f = fopen(FileName);
 C = textscan(f, '%f32 %f32', 'HeaderLines', 1);% use the following if there is a header to be removed, "'HeaderLines', 1);"
 test = transpose(C{1,1}*(pix_size/1000)); %pix_size converts to um which is necessary for the Andor system
 fclose(f);
 %End of file loader
 
 %Investigate the origin of negative alpha values

walklength = size(test,2); hold(handles.Random_walk,'off');
plot(handles.Random_walk,test); hold(handles.Random_walk,'on');
ylabel('position');
xlabel('time'); 
xaxislength = axis (handles.Random_walk);
if isnan(windowidth);
    windowidth = walklength -1;
    max_win = 0.2;
else max_win = 1;
end
   
    ylabel(handles.DvA,'alpha'); axis (handles.DvA,[0 xaxislength(2) -2 2]);
    xlabel(handles.DvA, 'D');
    
    ylabel(handles.Hist,'alpha');
    xlabel(handles.Hist,'D');
%----------------

% Uncomment the section here for mean-var plots
% for step = 1:(length-block);
%     mn(step) = mean(test(step:step+block));
%     vnce(step) = var(test(step:step+block));
% end
% subplot(3,1,2)
% scatter((mn),log(vnce),'r.')
% ylabel('mean')
% xlabel('ln(Var)')

%----------------

% MSD generator

% time = (1:windowidth);
% %plot(X1 = log10(time);
% X1=reshape(log10(time),[],1); % Changes X1 from a row to column 
%avg = zeros(windowidth,(length-windowidth));

%****************************
%The following code was generated to clean up the sliding window
%calculation. See 'DvA tested MSD and sliding window calculator.m'
axes(handles.Hist); %Clear axes for histogram
cla reset;
for slide = 1:(walklength-windowidth);
    if slide + windowidth > walklength;
        'sorry too big a window'; break;
    end
    for offset = 1:windowidth*max_win;
        A = double(test(slide:windowidth+slide-1)); %This is the selected string of data from test. 
        B(1,offset:windowidth) = double(test(slide:windowidth-offset+slide)); %The data from test to be subtracted for the MSD, it moves along according to offset, which effectively makes it a sliding window for the MSD 
        C = A-B;
        MSD(offset,slide) = mean(C(1,offset:windowidth).^2); %The difference squared, and only the meaningful data is used.
        % end
        %sum(MSD-XL_MSD)%for testing
        %  plot(MSD);  axis([0 500 0 200]); hold on;
        
        %Fit the MSD so far....
        y = log10(MSD(2:end,slide));  %y is logged and so is x - for log-log plot
        time = (1:(size(y,1)))*acq_time; % The acq_time value here is the time per frame in secs
        x = transpose(log10(time));
        %plot(x,y,'green'); hold on;%for testing
        
        
        P = polyfit(x(1:offset-1),y(1:offset-1),1); %fit the data
        
        yfit = P(1)*x(1:offset-1)+P(2); % calculate perfect fit
        %plot(x(1:offset-1),yfit,'r-'); hold off;
        yresid = y(1:offset-1) - yfit; %these are the fit residuals
        %This section calculated the r-squared (rsq)
        SSresid = sum(yresid.^2); 
        SStotal = (length(y(1:offset-1))-1) * var(y(1:offset-1));
        rsq = 1 - SSresid/SStotal;
        %end of rsq calculation
        fitparams(offset,:) = [P(1),P(2), rsq]; %Store the fit parameters helps for testing and is overwritten each slide of the window
        if fitparams(offset,3) < 0.8; % Checks quality of fit, having rsq so high keeps the fit to the early part of the data
            reject(end+1,:) = [slide offset rsq]; %stores rejection values, good for debugging
            
            break;
        end
        clear A B C;
    end
    offset = 1;
    clear A B C;
%     plot(x,y,'blue'); hold on;
%     plot(x,yfit,'r-');%for testing
    
    
    alph(slide) = P(1); %alpha is the slope of the log-log plot
    diff(slide) = (10^(P(2)))/2; %diff is the intercept so inv logged and divided by two.
    plot(handles.Hist,(log10(diff(slide))),alph(slide),'r.'); %Live update of DvA histogram
    if (log10(diff(slide))/(alph(slide)))< -2; %log10(diff(slide)) < -1;
        plotrange = transpose(slide:slide+windowidth);
        %hold(handles.Random_walk,'on');
        plot(handles.Random_walk,plotrange,test(:,slide:slide+windowidth), 'r-'); %red line is diffusion
        drawnow;
    else
        plotrange = transpose(slide:slide+windowidth);
        plot(handles.Random_walk,plotrange,test(:,slide:slide+windowidth), 'g-'); %green line is pausing
        drawnow;
    end
    plot(handles.DvA,slide, log10(diff(slide)),'r.'); %Plot in red the log10(diffusion constant)
    plot(handles.DvA,slide, (alph(slide)),'b.'); %Plot in blue the alpha
    plot(handles.DvA,slide, (log10(diff(slide))/(alph(slide))),'g.'); %Plot in green the log10(diff)/alpha ratio
    drawnow; hold(handles.DvA, 'on');hold(handles.Hist, 'on'); axis (handles.DvA,[0 xaxislength(2) -10 2]);
end
%End of MSD generator
%----------

% Plot MSD values
% time = (1:size(avg,2));
% X1 = log10(time);
% Y1 = log10(avg);
% %%plot1 = plot(log(time),log(avg));
% plot(X1,Y1)
% hold on;
%End of plot MSDs
%----------

%Fit plots
% clear yfit P
% P = polyfit(X1,Y1,1);
% yfit = P(1)*X1+P(2);%*X1+P(3);
%  
%     plot(X1,yfit,'r-.');
% End fit plots
%----------

% Calculate alpha and Diffusion constant (corrected for 2xslope)
%      a(rpt)=P(1);
%      D(rpt)=(10^(P(2)))/2;
% End of calculate alpha and Diffusion constant
%----------
alph_stor{win,b} = alph;
assignin('base','alph_stor',alph_stor);
diff_stor{win,b} = diff;
assignin('base','diff_stor',diff_stor);


% This cuts out the zeros and bad fits from the D and alpha then displays
% average results
%  a = a(D ~= 0);
%  D = D(D ~= 0);
%  mean(a)
%  mean(D)
%      alph = alph(diff ~= 0);
%     diff = diff(diff ~= 0);

% plot(handles.DvA,(log10(diff)),alph,'r.')
% ylabel('alpha')
% xlabel('D')
%axis([-4 4 -1 2])
hold on;
clear alph;
clear diff; hold(handles.DvA, 'off'); 
% ison4 = get(handles.multiwindow,'Value');
% if ison4 == 1;
%     hold(handles.Hist, 'off');
% end