%This program will load any number of txt files and extract the first
%column of data to take the position and then put the values into a new
%file with a new filename that is set by the user. This gives the correct
%format for DvA

clearvars;

[FileName,PathName,FilterIndex] = uigetfile('*.txt', 'MultiSelect', 'on');
cd(PathName);
delimiter = ' ';
startRow = 2; %gets rid of header
BaseName = inputdlg({'Filename'}, 'Save as...', [1 50]);
BaseName =  cell2mat(strcat(BaseName,'_'));
d = dir([PathName, '\*.txt']);

for loading = 1: length(d);

%% Format string for each line of text:
%   column1: double (%f)
% For more information, see the TEXTSCAN documentation.
formatSpec = '%f%*s%*s%*s%*s%*s%*s%[^\n\r]';

%% Open the text file.
eachfilename = d(loading).name;
fileID = fopen(eachfilename,'r');

%% Read columns of data according to format string.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'MultipleDelimsAsOne', true, 'HeaderLines' ,startRow-1, 'ReturnOnError', false);

%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

%% Allocate imported array to column variable names
data = dataArray{:, 1};
%%data = dataArray{:, 1};

%% Save the data in an incrementing file number
filepart = [PathName,BaseName,num2str(loading),'.txt'];
fileID = fopen(filepart,'w+');
fprintf(fileID,'%1.4f\r\n', data);
fclose(fileID);

end
plot(data);


