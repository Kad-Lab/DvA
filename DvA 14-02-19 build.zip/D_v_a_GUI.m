%18-3-18 build

function varargout = D_v_a_GUI(varargin)
% D_V_A_GUI M-file for D_v_a_GUI.fig
%      D_V_A_GUI, by itself, creates a new D_V_A_GUI or raises the existing
%      singleton*.
%
%      H = D_V_A_GUI returns the handle to a new D_V_A_GUI or the handle to
%      the existing singleton*.
%
%      D_V_A_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in D_V_A_GUI.M with the given input arguments.
%
%      D_V_A_GUI('Property','Value',...) creates a new D_V_A_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before D_v_a_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to D_v_a_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help D_v_a_GUI

% Last Modified by GUIDE v2.5 05-Dec-2012 16:28:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @D_v_a_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @D_v_a_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before D_v_a_GUI is made visible.
function D_v_a_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to D_v_a_GUI (see VARARGIN)

% Choose default command line output for D_v_a_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);



% UIWAIT makes D_v_a_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = D_v_a_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function filestem_Callback(hObject, eventdata, handles)
% hObject    handle to filestem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filestem as text
%        str2double(get(hObject,'String')) returns contents of filestem as a double


% --- Executes during object creation, after setting all properties.
function filestem_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filestem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Go.
function Go_Callback(hObject, eventdata, handles)
% hObject    handle to Go (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
assignin('base','win',1);
cla;
FileName = evalin('base', 'FileName');
PathName = evalin('base', 'PathName');
set(handles.path,'String',PathName); 
cd(PathName);
set(handles.file_name,'String',FileName);
File_Loader;
%testes;

% --- Executes on button press in togglebutton1.
function togglebutton1_Callback(hObject, eventdata, handles)
% hObject    handle to togglebutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebutton1


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in singlewindow.
function singlewindow_Callback(hObject, eventdata, handles)
% hObject    handle to singlewindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of singlewindow
ison3 = get(handles.multiwindow,'Value');
if ison3
    set(handles.multiwindow,'Value',0);
end

% --- Executes on button press in multiwindow.
function multiwindow_Callback(hObject, eventdata, handles)
% hObject    handle to multiwindow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of multiwindow
ison4 = get(handles.multiwindow,'Value');
if ison4
    set(handles.singlewindow,'Value',0);
end

% --- Executes on button press in loadfile.
function loadfile_Callback(hObject, eventdata, handles)
% hObject    handle to loadfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName,FilterIndex] = uigetfile('*.txt');
set(handles.path,'String',PathName); 
cd(PathName);
%set(handles.file_name,'String',FileName);

f = fopen(FileName);
 C = textscan(f, '%f32 %f32', 'HeaderLines', 1);% use the following if there is a header to be removed, "'HeaderLines', 1);"
 test = transpose(C{1,1});
 fclose(f);
 walklength = size(test,2);
 name = [FileName 32 num2str(walklength)];
 set(handles.file_name,'String',name);
assignin('base','FileName',FileName);
assignin('base','PathName',PathName);


% --- Executes on button press in singlefile.
function singlefile_Callback(hObject, eventdata, handles)
% hObject    handle to singlefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of singlefile
ison = get(hObject,'Value');
if ison
    set(handles.multifile,'Value',0)
end

% --- Executes on button press in multifile.
function multifile_Callback(hObject, eventdata, handles)
% hObject    handle to multifile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of multifile
ison2 = get(hObject,'Value');
if ison2
    set(handles.singlefile,'Value',0)
    popup_strt_end;
end

% --- Executes on key press with focus on loadfile and none of its controls.
function loadfile_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to loadfile (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when entered data in editable cell(s) in window_size.
function window_size_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to window_size (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
% window_sizes = get(hObject,'data');
% assignin('base', 'window_sizes', window_sizes);


% --- Executes during object creation, after setting all properties.
function window_size_CreateFcn(hObject, eventdata, handles)
% hObject    handle to window_size (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes during object creation, after setting all properties.
function Random_walk_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Random_walk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate Random_walk


% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure

try
    alph_stor = evalin('base','alph_stor');
    %diff_stor = evalin('base','diff_stor');
    
    sum(sum(cellfun('prodofsize', alph_stor)))
catch delete(hObject);
end
delete(hObject);
