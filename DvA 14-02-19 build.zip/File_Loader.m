% %Set this up as a function with the variables being passed directly?
% function [mean,stdev] = stat(x)
% n = length(x);
% mean = sum(x)/n;
% stdev = sqrt(sum((x-mean).^2/n));

%==============This code gets the frame rate and pixel size which is used in testes.
definput = {'0.1','63.2'};
acq_time_entry = inputdlg({'Enter frame time in seconds','Enter pixel size'},'Input',[1 35],definput); 
acq_time = str2num(acq_time_entry{1,1});
pix_size = str2num(acq_time_entry{2,1});
assignin('base','acq_time',acq_time);
assignin('base','pix_size',pix_size);
%==============


figure(D_v_a_GUI);
win = 1; b =1;
FileName = evalin('base', 'FileName');

[path, name, ext] =fileparts(FileName);
name = strtok(FileName,'_');
flagwind = get(handles.singlewindow,'Value');
flagfile = get(handles.singlefile,'Value');

window_sizes = get(handles.window_size,'data');
assignin('base','windows',window_sizes);
set(handles.Go,'String','Going');
if flagwind
    windowidth = window_sizes(1);
    
    if flagfile
        testes;
    else
        st_file_no = evalin('base', 'st_file_no');
        end_file_no = evalin('base', 'end_file_no');
        for b = st_file_no:end_file_no;
            newfile =  [path name '_' (num2str(b)) ext];
            assignin('base','FileName',newfile);
            set(handles.file_name,'String',FileName);
            testes;
            windowidth = window_sizes(1);
        end
    end
    
else
    
    while win <= 6;
        
        windowidth = window_sizes(win);
        
        
        
        if flagfile
            testes;
        else
            st_file_no = evalin('base', 'st_file_no');
            end_file_no = evalin('base', 'end_file_no');
            for b = st_file_no:end_file_no;
                newfile =  [path name '_' (num2str(b)) ext];
                assignin('base','FileName',newfile);
                set(handles.file_name,'String',FileName);
               
                testes;
                windowidth = window_sizes(win);
              
            end
        end
    win = win +1;    
    end
end
if flagwind
    win = 2;
end
diff_comp = horzcat(diff_stor{1,:});
alph_comp = horzcat(alph_stor{1,:});
%diff_comp{1,1} = diff_stor{1,1};% restore these if you're having troubles
%with diff_comp, and also the compress loop below
%alph_comp{1,1} = alph_stor{1,1};

% for compress = 2:(win-1);
%     diff_temp = horzcat(diff_stor{compress,:});
%     diff_comp{1,1} = horzcat(diff_temp,diff_comp{1,1});
%     alph_temp = horzcat(alph_stor{compress,:});
%     alph_comp{1,1} = horzcat(alph_temp,alph_comp{1,1});
%     clear alph_temp; clear diff_temp;
% end

set(handles.Go,'String','Go'); set(handles.file_name,'String',FileName);
save('diff_comp','diff_comp');
save('alph_comp','alph_comp');
save('alph_stor','alph_stor'); save('diff_stor','diff_stor');


% Should the data be analysed? Dialog box popup. Remove this for old
% analysis or multiple file analysis

%Currently commented to allow for multi-file, multi-window analysis


choice = questdlg('Analyze this data?', ...
	'Yes','No');
% Handle response
switch choice
    case 'Yes'
        addpath('C:\Users\nkad\Dropbox\Papers\XPD paper\Trajectory data\');
        Analysis;
        answer = 1;
    case 'No'
        answer = 2;
    
end

