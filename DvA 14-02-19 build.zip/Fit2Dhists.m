%Make the variable x have two columns, first with natural log of D and the
%second with alpha




for q = 1:2
logx = x;
%plot(logx(:,1),logx(:,2), 'o')
plot(x(:,1),x(:,2), 'o')
hold on;
options = statset('Display','final');
obj = gmdistribution.fit(logx,q,'Options',options); %Change q to a number and get rid of the for next loop to fit a single


 %h = ezcontour(@(x,y)pdf(obj,[x y]),[-10 2 -2 2]); 
 %val = ezcontour(h, [-10 2 -2 2]);
hold off;
inlogx=exp(obj.mu(:,1))
obj.mu(:,2)
bic(2,q)= obj.BIC;
bic (1,q) = q;

end
hold on;
 h = ezcontour(@(x,y)pdf(obj,[x y]),[-10 2 -2 2]); 
 val = ezcontour(h, [-10 2 -2 2]);
% f = transpose(bic);
% clf;
% plot(f(1,:), f(2,:));


% for k = 1:4
% obj{k} = gmdistribution.fit(logx,k);
% BIC(k)= obj{k}.BIC;
% end
% [minBIC,numComponents] = min(BIC);
% % numComponents


% The following is to create 2D hists using covariance to alter their
% shape. This is really good for understanding the meaning of the vector
% components.

% mu = [-5.25979 0.783676];
% SIGMA = [0.835 -0.0515; -0.0515 0.1452];
% r = mvnrnd(mu,SIGMA,1000);
% mu2 = [-8.94171 0.325911];
% SIGMA2 = [2.898 0.1287; 0.1287 0.0294];
% r2 = mvnrnd(mu2,SIGMA2,1000);
% plot(r(:,1),r(:,2),'+'); hold on
% plot(r2(:,1),r2(:,2),'r+')
% axis([-15 0 -1 2]);
% hold off;