function choice = Decide
global X1 Y1 rescaled;
choice = menu('Restart threshold?', 'Yes','No','Axes', 'Reset'); 
if choice == 1;
     Analysis;
 elseif choice ==3;
     [X1 Y1] = ginput(1); %get x & y position from mouse cursor
     axis ([0 X1 0 Y1]); rescaled = 1;
     Decide;
elseif choice ==4;
    rescaled =0; 
    Analysis;
 end
end