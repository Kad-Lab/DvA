% Should the data be analysed? Dialog box popup.
choice = questdlg('Analyze this data?', ...
	'Yes','No');
% Handle response
switch choice
    case 'Yes'
        %cd('C:\Users\nkad\Dropbox\Papers\XPD paper\Trajectory data\');
        Analysis;
        answer = 1;
    case 'No'
        answer = 2;
    
end